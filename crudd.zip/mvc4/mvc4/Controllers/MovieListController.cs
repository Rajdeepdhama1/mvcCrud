﻿using Microsoft.AspNetCore.Mvc;
using mvc4.Models;
using System.Collections.Generic;
using System.Linq;

namespace mvc4.Controllers
{
    public class MovieListController : Controller
    {
        public IActionResult Index()
        {
            List<Movie> movies = MovieData.GetMoviesData();
            return PartialView(movies);
        }
        public IActionResult SearchById(int id)
        {
            var movie = MovieData.GetFilteredMovie(id);
            return PartialView("_FilterMoviePartial",movie);
        }
        public IActionResult Insertion()
        {
            return View();
        }
      
        public IActionResult MovieList()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddNewMovie(Movie model)
        {
            List<Movie> movies= MovieData.AddMovie(model);
            return View("MovieList", movies);
        }
        public IActionResult DeleteById(int id)
        {
            var movie = MovieData.GetFilteredMovie(id);
            List<Movie> movies = MovieData.GetMoviesData();
            movies = movies.Where(x => x.MovieId != id).ToList();
            return PartialView("_MovieDetailsPartial", movies);
        }
        public IActionResult Updation()
        {
            return View();
        }

        [HttpPost]
        public IActionResult UpdateMovie(Movie model)
        {
            List<Movie> movies = MovieData.EditMovie(model);
            return View("MovieList", movies);
        }

    }
}