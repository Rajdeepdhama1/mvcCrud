﻿using mvc4.Models;
using System.Collections.Generic;
using System.Linq;

namespace mvc4
{
    public class MovieData
    {
          public static List<Movie> GetMoviesData()
        {
            List<Movie> movies = new List<Movie>();
            Movie m = new Movie()
            {
                MovieId = 1,
                MovieName = "Titanic",
                ReleaseYear = "1998",
                Genre = "Romance"
            };

            Movie m1 = new Movie()
            {
                MovieId = 2,
                MovieName = "Forest Gump",
                ReleaseYear = "1995",
                Genre = "Fiction"
            };

            Movie m2 = new Movie()
            {
                MovieId = 3,
                MovieName = "Bahubali",
                ReleaseYear = "2013",
                Genre = "Fiction"
            };

            Movie m3 = new Movie()
            {
                MovieId = 4,
                MovieName = "The Dark Knight",
                ReleaseYear = "2007",
                Genre = "Action"
            };

            Movie m4 = new Movie()
            {
                MovieId = 5,
                MovieName = "The Shawshank Redemption",
                ReleaseYear = "1988",
                Genre = "Fiction"
            };
            movies.Add(m);
            movies.Add(m1);
            movies.Add(m2);
            movies.Add(m3);
            movies.Add(m4);
            return movies;
        }

        public static Movie GetFilteredMovie( int id)
        {
           return GetMoviesData().Where(x => x.MovieId == id).FirstOrDefault();
        }
        public static List<Movie> AddMovie(Movie model)
        {
            var obj=model;
            List<Movie> movies = MovieData.GetMoviesData();
            movies.Add(obj);
            return movies;
        }
        public static List<Movie> EditMovie(Movie model)
        {
            var obj = model;
            List<Movie> movies = MovieData.GetMoviesData();
            Movie movie = movies.Where(x => x.MovieId == obj.MovieId).Select(x => { x = obj; return x; }).FirstOrDefault();
            movies.RemoveAll(x => x.MovieId == model.MovieId);
            movies.Add(movie);
            return movies.OrderBy(x=>x.MovieId).ToList();
        }

    }
}
